<?php
/**
 * Created by PhpStorm.
 
 */

header("Location: ../");