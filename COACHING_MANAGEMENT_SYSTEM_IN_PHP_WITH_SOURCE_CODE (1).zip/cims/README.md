# CIMS
CIMS is complete coaching management system in php 

CIMS Stands for coaching instiute management system, it is built in php and database is mySql.
One coaching center can have many center accross the globe so cims is bulit with keeping in mind about this thing 

CIMS contains 7 modules
  1. Super Admin (Admin of main/Head center)
  2. Admin (Each Center has their own "Center Admin")
  3. HOD (Each Center has subject wise HOD's)
  4. Mentor (Each Batch in each center has their own mentors)
  5. Teacher (Each center has their own teachers and their accounts)
  6. Student (Each student of each center has different accounts)
  7. Parents (Each Parent have different account)
  
Each Admin,hod's,mentor,teacher,student,parents have their own unique id which is provided by admin of center who register/add the student and verify their details.

Each cims member of Coaching has their own functionality in cims.

By using cims parents can easily check their report and progress.
Cims include various many features like parents can make complaint to admin,teacher,hod and mentor which help parents to take care of his ward

CIMS maintains an hierarchy for performing tasks. Which make it best and light weight in terms of task and server load.

# 👍 Contribution
1. Fork it
2. Create your feature branch (git checkout -b my-new-feature)
3. Commit your changes (git commit -m 'Add some feature')
4. Push to the branch (git push origin my-new-feature)
5. Create new Pull Request


