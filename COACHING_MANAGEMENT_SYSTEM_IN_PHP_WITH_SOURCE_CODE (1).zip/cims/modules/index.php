<?php
/**
 * Created by PhpStorm.
 * User: Bharat
 * Date: 6/27/2018
 * Time: 9:12 AM
 */

header("Location: ../");